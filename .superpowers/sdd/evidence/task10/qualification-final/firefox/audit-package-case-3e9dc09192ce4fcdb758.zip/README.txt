CAOS audit package

Verify offline, on any machine with Python 3.12+ and no CAOS install:

    python verify_package.py <this zip>

The verifier (caos/server/caos/audit/verify_package.py in the CAOS repository)
recomputes every object digest in manifest.json, the per-case audit chain,
every frozen deliverable's content and approval digests, every filing receipt
and its cross-references, the signer/approver separation, the exact filed
export bytes, the run plan and snapshot digests, the model payload digests,
and re-renders each Markdown export from its frozen payload byte for byte.

Nothing in this package is a secret, a prompt, a provider message body or
source-document text: sources carry block ids and text digests only.
